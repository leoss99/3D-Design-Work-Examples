# Assignment 1
A1 code for students.
Name: Leo Sun(same as Canvas name)
student number: 57859936
CWL: sunyenon

